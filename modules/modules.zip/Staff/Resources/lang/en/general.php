<?php

return [

    'name'              => 'Staff',
    'description'       => 'This is my awesome module',

];