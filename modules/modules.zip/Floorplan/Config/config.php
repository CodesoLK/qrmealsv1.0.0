<?php

return [
    'name' => 'Floorplan'
];
